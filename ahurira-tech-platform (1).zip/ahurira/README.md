# AHURIRA TECH — Platform Codebase

Uganda's AI-powered multi-vertical platform: **AI · Music · Film · Student Portal**, built on
React + FastAPI + Claude, following the AHURIRA TECH Coding Master Plan.

This repo implements **Phase 1 (Foundation)**, **Phase 2 (AI Core)**, and the initial slice of
**Phase 3 (Product Engines)** and **Phase 4 (Frontend)** from the roadmap — a working, runnable
skeleton you can build the rest of the platform on top of.

## What's implemented

- ✅ JWT auth (register / login / refresh / me) with bcrypt password hashing
- ✅ FastAPI backend with the exact folder structure from the master plan
- ✅ SQLAlchemy 2 async models: `User`, `Track` (Music), `Film`, `StudentProfile` + `TuitionPayment`
- ✅ Claude API service layer (`ai_service.py`) — chat, MIRA chatbot, song concepts, film scripts, content verification
- ✅ Celery + Redis task queue wired up with example AI, media (FFmpeg), and email tasks
- ✅ Alembic migrations configured (async-aware `env.py`)
- ✅ React 18 + TypeScript + Tailwind frontend with routing, Zustand auth store, React Query, Axios interceptors (incl. auto token refresh)
- ✅ Pages for all 4 engines: AI chat, Music (AI song concepts), Film (AI script generator), Student Portal (records / finance / MIRA / elections)
- ✅ Docker Compose for the full local stack (Postgres, Redis, API, Celery worker, frontend)
- ✅ GitHub Actions CI (backend pytest + frontend build)
- ✅ Pytest test suite (health checks, auth validation)

## What's stubbed / left for you to wire up

These need real credentials or further build-out — they're structured but not connected to live
external services:

- **Sonauto** (AI music generation) and **Seedance** (AI video generation) — API clients aren't
  implemented yet; `ai_service.py` currently generates *song concepts/scripts* via Claude, not
  actual audio/video.
- **Pinecone** vector store — not yet wired into the AI orchestrator for semantic memory/search.
- **MTN Mobile Money / Airtel Money** — finance tab is UI-only; no live payment gateway calls.
- **Cloudflare R2** — no upload/storage client yet; track/film URLs are just DB columns for now.
- **LangChain agents** — the AI Core uses the Anthropic SDK directly; LangChain orchestration
  (agents, tool use, chains) from Layer 4 hasn't been layered on top yet.
- **React Native mobile app** — not started; this repo is web only.

## Project structure

```
ahurira/
├── backend/                 # FastAPI + Python
│   ├── app/
│   │   ├── main.py          # App entry point
│   │   ├── core/            # config, database, security (JWT/bcrypt)
│   │   ├── models/          # SQLAlchemy models
│   │   ├── schemas/         # Pydantic schemas
│   │   ├── routers/         # auth.py, ai.py
│   │   ├── services/        # ai_service.py, user_service.py
│   │   └── tasks/           # Celery app + AI/media/email tasks
│   ├── migrations/          # Alembic
│   ├── tests/
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/                 # React + TypeScript + Tailwind
│   └── src/
│       ├── pages/            # auth, dashboard, ai, music, film, portal
│       ├── components/layout/
│       ├── services/         # apiClient, authService, aiService
│       └── store/            # Zustand authStore
├── docker-compose.yml
└── .github/workflows/ci.yml
```

## Running locally

### Option A — Docker Compose (recommended)

```bash
cd ahurira
cp backend/.env.example backend/.env
# Edit backend/.env and add your ANTHROPIC_API_KEY at minimum

docker compose up --build
```

- API: http://localhost:8000 (docs at `/docs`)
- Frontend: http://localhost:3000

### Option B — Manual

**Backend:**
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # add your ANTHROPIC_API_KEY

# Start Postgres & Redis yourself, or via:
docker compose up db redis -d

alembic upgrade head    # or rely on init_db() auto-create on startup (dev only)
uvicorn app.main:app --reload
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

### Running tests

```bash
cd backend
pytest -v
```

## Environment variables

See `backend/.env.example` for the full list. At minimum, set `ANTHROPIC_API_KEY` to use any
AI feature (chat, MIRA, song concepts, film scripts, content verification).

## Next steps (suggested build order)

1. Wire up Sonauto + Seedance API clients in `services/music_service.py` / `services/film_service.py` (create these — they're referenced in the master plan's folder structure but not yet built).
2. Add Pinecone embeddings to `ai_service.py` for conversation memory and semantic search.
3. Build out `routers/music.py`, `routers/film.py`, `routers/portal.py` with full CRUD for tracks, films, payments.
4. Add MTN MoMo / Airtel Money sandbox integration behind `services/payment_service.py`.
5. Add Cloudflare R2 upload endpoints (presigned URLs) for track/film/avatar uploads.
6. Layer LangChain agents on top of the existing Claude calls for the "AI Agents" feature (autonomous research/writing/data-analysis tasks).
7. Scaffold the React Native app sharing the component library conventions already established.

---
*AHURIRA TECH LIMITED — Kampala, Uganda. Internal technical document → working code.*
