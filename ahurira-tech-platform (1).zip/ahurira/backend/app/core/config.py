from pydantic_settings import BaseSettings
from pydantic import AnyHttpUrl
from typing import List
import os


class Settings(BaseSettings):
    # Application
    APP_NAME: str = "AHURIRA TECH API"
    APP_ENV: str = "development"
    DEBUG: bool = True
    SECRET_KEY: str = "change-me-in-production"

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://ahurira:password@localhost:5432/ahurira_db"
    DATABASE_SYNC_URL: str = "postgresql://ahurira:password@localhost:5432/ahurira_db"

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"

    # JWT
    JWT_SECRET_KEY: str = "change-me-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # AI Services
    ANTHROPIC_API_KEY: str = ""
    GOOGLE_API_KEY: str = ""
    PINECONE_API_KEY: str = ""
    PINECONE_INDEX: str = "ahurira-index"

    # Storage
    R2_ACCESS_KEY_ID: str = ""
    R2_SECRET_ACCESS_KEY: str = ""
    R2_BUCKET_NAME: str = "ahurira-media"
    R2_ENDPOINT_URL: str = ""

    # Third-party APIs
    SONAUTO_API_KEY: str = ""
    SEEDANCE_API_KEY: str = ""
    MTN_MOMO_API_KEY: str = ""
    MTN_MOMO_SECRET: str = ""
    MTN_MOMO_SUBSCRIPTION_KEY: str = ""
    AIRTEL_API_KEY: str = ""
    AIRTEL_API_SECRET: str = ""

    # CORS
    CORS_ORIGINS: str = "http://localhost:3000,http://localhost:5173"

    @property
    def cors_origins_list(self) -> List[str]:
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",")]

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
