import uuid
from datetime import datetime, timezone
from sqlalchemy import String, Boolean, DateTime, Integer, Float, ForeignKey, Text, Enum as SAEnum, JSON
from sqlalchemy.orm import Mapped, mapped_column
from app.core.database import Base
import enum


class FilmStatus(str, enum.Enum):
    processing = "processing"
    published = "published"
    rejected = "rejected"
    draft = "draft"


class FilmType(str, enum.Enum):
    short = "short"
    feature = "feature"
    documentary = "documentary"
    ad = "ad"
    ai_generated = "ai_generated"


class Film(Base):
    __tablename__ = "films"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    creator_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    film_type: Mapped[FilmType] = mapped_column(SAEnum(FilmType), default=FilmType.short)
    video_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    thumbnail_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    trailer_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    duration_seconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    view_count: Mapped[int] = mapped_column(Integer, default=0)
    is_ai_generated: Mapped[bool] = mapped_column(Boolean, default=False)
    ai_script: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[FilmStatus] = mapped_column(SAEnum(FilmStatus), default=FilmStatus.draft)
    is_premium: Mapped[bool] = mapped_column(Boolean, default=False)
    price_ugx: Mapped[float | None] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
