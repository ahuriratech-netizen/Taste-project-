from app.tasks.celery_app import celery_app


@celery_app.task(name="email.send_welcome")
def send_welcome_email_task(to_email: str, full_name: str):
    """Send a welcome email after registration. Wire up to an actual provider (SES/SendGrid) in production."""
    # TODO: integrate with a transactional email provider
    print(f"[email] Welcome email queued for {full_name} <{to_email}>")
    return {"status": "sent", "to": to_email}


@celery_app.task(name="email.send_payment_receipt")
def send_payment_receipt_task(to_email: str, amount_ugx: float, transaction_ref: str):
    """Send a tuition payment receipt email."""
    print(f"[email] Receipt queued for {to_email}: UGX {amount_ugx:,.0f} ({transaction_ref})")
    return {"status": "sent", "to": to_email}
