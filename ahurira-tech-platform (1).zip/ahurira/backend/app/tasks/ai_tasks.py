from app.tasks.celery_app import celery_app
from app.services.ai_service import AIService
import asyncio


@celery_app.task(name="ai.generate_music_concept", bind=True, max_retries=2)
def generate_music_concept_task(self, prompt: str, genre: str = "", mood: str = ""):
    """Background job: generate a song concept via Claude without blocking the request."""
    try:
        service = AIService()
        result = asyncio.run(service.generate_song_concept(prompt, genre, mood))
        return result
    except Exception as exc:
        raise self.retry(exc=exc, countdown=10)


@celery_app.task(name="ai.generate_film_script", bind=True, max_retries=2)
def generate_film_script_task(self, prompt: str, style: str = ""):
    """Background job: generate a film script via Claude."""
    try:
        service = AIService()
        result = asyncio.run(service.generate_film_script(prompt, style))
        return result
    except Exception as exc:
        raise self.retry(exc=exc, countdown=10)


@celery_app.task(name="ai.verify_content")
def verify_content_task(content: str, content_type: str = "text"):
    """Background job: run content verification scoring."""
    service = AIService()
    return asyncio.run(service.verify_content(content, content_type))
