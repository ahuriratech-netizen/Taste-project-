import subprocess
from app.tasks.celery_app import celery_app


@celery_app.task(name="media.transcode_audio", bind=True, max_retries=2)
def transcode_audio_task(self, input_path: str, output_path: str, bitrate: str = "192k"):
    """Transcode an uploaded audio file to a standard streaming format using FFmpeg."""
    try:
        subprocess.run(
            [
                "ffmpeg", "-y", "-i", input_path,
                "-codec:a", "libmp3lame", "-b:a", bitrate,
                output_path,
            ],
            check=True,
            capture_output=True,
        )
        return {"status": "completed", "output_path": output_path}
    except subprocess.CalledProcessError as exc:
        raise self.retry(exc=exc, countdown=15)


@celery_app.task(name="media.transcode_video_abr", bind=True, max_retries=2)
def transcode_video_abr_task(self, input_path: str, output_dir: str):
    """Transcode video into multiple bitrate renditions for adaptive bitrate streaming."""
    renditions = [
        {"name": "480p", "scale": "854:480", "bitrate": "1000k"},
        {"name": "720p", "scale": "1280:720", "bitrate": "2500k"},
        {"name": "1080p", "scale": "1920:1080", "bitrate": "5000k"},
    ]
    outputs = []
    try:
        for r in renditions:
            out_path = f"{output_dir}/{r['name']}.mp4"
            subprocess.run(
                [
                    "ffmpeg", "-y", "-i", input_path,
                    "-vf", f"scale={r['scale']}",
                    "-c:v", "libx264", "-b:v", r["bitrate"],
                    "-c:a", "aac", "-b:a", "128k",
                    out_path,
                ],
                check=True,
                capture_output=True,
            )
            outputs.append(out_path)
        return {"status": "completed", "renditions": outputs}
    except subprocess.CalledProcessError as exc:
        raise self.retry(exc=exc, countdown=20)
