from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.security import get_current_active_user
from app.services.ai_service import AIService
from app.schemas.ai import (
    ChatRequest, ChatResponse,
    AgentRequest, AgentResponse,
    MusicGenerationRequest,
    VideoGenerationRequest,
)

router = APIRouter(prefix="/ai", tags=["AI Engine"])


@router.post("/chat", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    current_user=Depends(get_current_active_user),
):
    """AHURIRA AI conversational chat endpoint."""
    try:
        service = AIService()
        result = await service.chat(
            message=request.message,
            user_id=current_user.id,
            history=request.conversation_history,
            system_prompt=request.system_prompt,
        )
        return ChatResponse(
            response=result["response"],
            tokens_used=result["tokens_used"],
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"AI service error: {str(e)}",
        )


@router.post("/mira/chat", response_model=ChatResponse)
async def mira_chat(
    request: ChatRequest,
    current_user=Depends(get_current_active_user),
):
    """MIRA — student portal AI assistant."""
    try:
        service = AIService()
        result = await service.mira_chat(
            message=request.message,
            student_id=current_user.id,
            history=request.conversation_history,
        )
        return ChatResponse(
            response=result["response"],
            tokens_used=result["tokens_used"],
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"MIRA service error: {str(e)}",
        )


@router.post("/music/concept")
async def generate_music_concept(
    request: MusicGenerationRequest,
    current_user=Depends(get_current_active_user),
):
    """Generate a song concept, lyrics and production notes with AI."""
    try:
        service = AIService()
        result = await service.generate_song_concept(
            prompt=request.prompt,
            genre=request.genre or "",
            mood=request.mood or "",
        )
        return result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Music generation error: {str(e)}",
        )


@router.post("/film/script")
async def generate_film_script(
    request: VideoGenerationRequest,
    current_user=Depends(get_current_active_user),
):
    """Generate a film script or concept with AI."""
    try:
        service = AIService()
        result = await service.generate_film_script(
            prompt=request.script,
            style=request.style or "",
        )
        return result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Script generation error: {str(e)}",
        )


@router.post("/verify")
async def verify_content(
    content: str,
    content_type: str = "text",
    current_user=Depends(get_current_active_user),
):
    """Run AI content verification and authenticity scoring."""
    try:
        service = AIService()
        return await service.verify_content(content, content_type)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Verification error: {str(e)}",
        )
