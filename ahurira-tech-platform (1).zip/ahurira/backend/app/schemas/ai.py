from pydantic import BaseModel
from typing import Optional, List
from enum import Enum


class MessageRole(str, Enum):
    user = "user"
    assistant = "assistant"


class ChatMessage(BaseModel):
    role: MessageRole
    content: str


class ChatRequest(BaseModel):
    message: str
    conversation_history: Optional[List[ChatMessage]] = []
    system_prompt: Optional[str] = None
    stream: bool = False


class ChatResponse(BaseModel):
    response: str
    tokens_used: int
    conversation_id: Optional[str] = None


class AgentRequest(BaseModel):
    task: str
    context: Optional[str] = None


class AgentResponse(BaseModel):
    result: str
    steps_taken: List[str] = []
    tokens_used: int


class MusicGenerationRequest(BaseModel):
    prompt: str
    genre: Optional[str] = None
    mood: Optional[str] = None
    duration_seconds: Optional[int] = 30


class VideoGenerationRequest(BaseModel):
    script: str
    style: Optional[str] = None
    duration_seconds: Optional[int] = 60
