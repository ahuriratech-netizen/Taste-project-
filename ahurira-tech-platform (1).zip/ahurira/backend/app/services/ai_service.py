import anthropic
from typing import List, Optional, AsyncIterator
from app.core.config import settings
from app.schemas.ai import ChatMessage


AHURIRA_SYSTEM_PROMPT = """You are AHURIRA AI, the intelligent assistant powering Uganda's leading
digital platform covering music, film, and education. You are built by AHURIRA TECH LIMITED,
based in Kampala, Uganda.

You help users with:
- Creative tasks: songwriting, scriptwriting, story development
- Research and analysis
- Student academic support (as MIRA for the student portal)
- General queries about the AHURIRA platform

Be concise, helpful, and culturally aware of the East African context.
"""

MIRA_SYSTEM_PROMPT = """You are MIRA, the intelligent academic assistant for students at Makerere
Institute of Research and Academia (MIRA), powered by AHURIRA TECH LIMITED.

You help students with:
- Course information and academic guidance
- Exam preparation and study tips
- Campus life and student services queries
- Understanding results and academic records
- Finance and fee payment questions

Always be supportive, clear, and encouraging. Keep responses concise and practical.
"""


class AIService:
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.model = "claude-sonnet-4-6"

    async def chat(
        self,
        message: str,
        user_id: str,
        history: Optional[List[ChatMessage]] = None,
        system_prompt: Optional[str] = None,
    ) -> dict:
        messages = []

        # Include conversation history
        if history:
            for msg in history[-10:]:  # Keep last 10 turns for context window
                messages.append({"role": msg.role.value, "content": msg.content})

        messages.append({"role": "user", "content": message})

        response = self.client.messages.create(
            model=self.model,
            max_tokens=2048,
            system=system_prompt or AHURIRA_SYSTEM_PROMPT,
            messages=messages,
        )

        return {
            "response": response.content[0].text,
            "tokens_used": response.usage.input_tokens + response.usage.output_tokens,
        }

    async def mira_chat(
        self,
        message: str,
        student_id: str,
        history: Optional[List[ChatMessage]] = None,
    ) -> dict:
        """MIRA — student portal AI assistant."""
        return await self.chat(
            message=message,
            user_id=student_id,
            history=history,
            system_prompt=MIRA_SYSTEM_PROMPT,
        )

    async def generate_song_concept(self, prompt: str, genre: str = "", mood: str = "") -> dict:
        """Generate lyrics, title, and structure for a song."""
        system = "You are a professional Ugandan/East African music producer and lyricist."
        user_msg = f"""Generate a complete song concept for:
Prompt: {prompt}
Genre: {genre or 'Afrobeats/Afropop'}
Mood: {mood or 'uplifting'}

Return:
1. Song title
2. Complete lyrics (verse 1, chorus, verse 2, bridge, outro)
3. Suggested tempo (BPM)
4. Key instruments
5. Production notes"""

        response = self.client.messages.create(
            model=self.model,
            max_tokens=1500,
            system=system,
            messages=[{"role": "user", "content": user_msg}],
        )
        return {
            "concept": response.content[0].text,
            "tokens_used": response.usage.input_tokens + response.usage.output_tokens,
        }

    async def generate_film_script(self, prompt: str, style: str = "") -> dict:
        """Generate a short film script or synopsis."""
        system = "You are an award-winning East African screenwriter and director."
        user_msg = f"""Write a short film concept for:
Prompt: {prompt}
Style: {style or 'Drama/Contemporary'}

Include:
1. Title and logline
2. Characters (3-5 with brief descriptions)
3. Three-act structure outline
4. Opening scene (full script format)
5. Key visual moments"""

        response = self.client.messages.create(
            model=self.model,
            max_tokens=2000,
            system=system,
            messages=[{"role": "user", "content": user_msg}],
        )
        return {
            "script": response.content[0].text,
            "tokens_used": response.usage.input_tokens + response.usage.output_tokens,
        }

    async def verify_content(self, content: str, content_type: str = "text") -> dict:
        """Content authenticity and verification scoring."""
        system = "You are a content verification AI specialist."
        user_msg = f"""Analyse this {content_type} for authenticity and quality:

{content}

Score (0-100) and explain:
1. Originality score
2. Quality score
3. Potential issues (plagiarism, misinformation, harmful content)
4. Recommendation: approve / review / reject"""

        response = self.client.messages.create(
            model=self.model,
            max_tokens=800,
            system=system,
            messages=[{"role": "user", "content": user_msg}],
        )
        return {
            "verification": response.content[0].text,
            "tokens_used": response.usage.input_tokens + response.usage.output_tokens,
        }
