import { useState, useRef, useEffect } from 'react'
import { useMutation } from '@tanstack/react-query'
import { GraduationCap, MessageCircle, CreditCard, FileText, Vote, Send, Bot, User, Loader2 } from 'lucide-react'
import { aiService, type ChatMessage } from '@/services/aiService'

const TABS = [
  { id: 'records', label: 'Academic Records', icon: FileText },
  { id: 'finance', label: 'Finance', icon: CreditCard },
  { id: 'mira', label: 'MIRA Chatbot', icon: MessageCircle },
  { id: 'elections', label: 'Guild Elections', icon: Vote },
]

export default function PortalPage() {
  const [activeTab, setActiveTab] = useState('mira')

  return (
    <div className="p-8">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3">
          <GraduationCap size={14} className="text-emerald-400" />
          <span className="text-emerald-400 text-sm font-medium uppercase tracking-wider">Student Portal</span>
        </div>
        <h1 className="font-display text-3xl font-bold text-white">Student Portal</h1>
        <p className="text-gray-400 mt-1">Academic records, payments, MIRA AI, and elections.</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-dark-600 pb-px">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors duration-200 ${
              activeTab === id
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
          >
            <Icon size={15} />
            {label}
          </button>
        ))}
      </div>

      {activeTab === 'records' && <RecordsTab />}
      {activeTab === 'finance' && <FinanceTab />}
      {activeTab === 'mira' && <MiraTab />}
      {activeTab === 'elections' && <ElectionsTab />}
    </div>
  )
}

function RecordsTab() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="card">
        <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">GPA</p>
        <p className="text-2xl font-bold text-white">4.32</p>
      </div>
      <div className="card">
        <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Year / Semester</p>
        <p className="text-2xl font-bold text-white">Year 2, Sem 1</p>
      </div>
      <div className="card">
        <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Exam Permit</p>
        <span className="badge bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Cleared</span>
      </div>
      <div className="card md:col-span-3">
        <p className="font-semibold text-white mb-3">Course Registration</p>
        <p className="text-sm text-gray-500">No courses registered for this semester yet.</p>
      </div>
    </div>
  )
}

function FinanceTab() {
  const [method, setMethod] = useState('mtn_momo')
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="card">
        <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Tuition Balance</p>
        <p className="text-3xl font-bold text-white mb-4">UGX 1,250,000</p>
        <div className="space-y-3">
          <label className="block text-sm font-medium text-gray-300">Payment method</label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'mtn_momo', label: 'MTN MoMo' },
              { id: 'airtel_money', label: 'Airtel Money' },
              { id: 'bank_transfer', label: 'Bank' },
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => setMethod(m.id)}
                className={`py-2 px-2 text-xs font-medium rounded-lg border transition-colors ${
                  method === m.id
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400'
                    : 'bg-dark-700 border-dark-500 text-gray-400'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
          <input className="input" placeholder="Amount (UGX)" />
          <button className="btn-primary bg-emerald-500 hover:bg-emerald-600 w-full">Pay now</button>
        </div>
      </div>
      <div className="card">
        <p className="font-semibold text-white mb-3">Payment History</p>
        <p className="text-sm text-gray-500">No payment history yet.</p>
      </div>
    </div>
  )
}

function MiraTab() {
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const bottomRef = useRef<HTMLDivElement>(null)

  const { mutate, isPending } = useMutation({
    mutationFn: (message: string) =>
      aiService.miraChat({ message, conversation_history: messages }),
    onSuccess: (data) => {
      setMessages((prev) => [...prev, { role: 'assistant', content: data.response }])
    },
  })

  const send = () => {
    if (!input.trim() || isPending) return
    const msg = input.trim()
    setInput('')
    setMessages((prev) => [...prev, { role: 'user', content: msg }])
    mutate(msg)
  }

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isPending])

  return (
    <div className="card flex flex-col h-[60vh]">
      <div className="flex items-center gap-2 mb-4 pb-4 border-b border-dark-600">
        <Bot size={18} className="text-emerald-400" />
        <div>
          <p className="font-semibold text-white">MIRA</p>
          <p className="text-xs text-gray-500">Your academic AI assistant</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 mb-4">
        {messages.length === 0 && (
          <p className="text-sm text-gray-500 text-center py-8">
            Ask MIRA about courses, exams, results, or campus services.
          </p>
        )}
        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-2.5 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-7 h-7 rounded-full flex-shrink-0 flex items-center justify-center text-xs ${
              msg.role === 'user' ? 'bg-brand-500/20 text-brand-400' : 'bg-emerald-500/20 text-emerald-400'
            }`}>
              {msg.role === 'user' ? <User size={12} /> : <Bot size={12} />}
            </div>
            <div className={`max-w-lg px-3.5 py-2.5 rounded-lg text-sm leading-relaxed ${
              msg.role === 'user'
                ? 'bg-brand-500/10 border border-brand-500/20 text-white'
                : 'bg-dark-700 border border-dark-600 text-gray-200'
            }`}>
              <pre className="whitespace-pre-wrap font-sans">{msg.content}</pre>
            </div>
          </div>
        ))}
        {isPending && <Loader2 size={16} className="text-emerald-400 animate-spin" />}
        <div ref={bottomRef} />
      </div>

      <div className="flex gap-2">
        <input
          className="input"
          placeholder="Ask MIRA…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send()}
        />
        <button onClick={send} disabled={isPending || !input.trim()} className="btn-primary bg-emerald-500 hover:bg-emerald-600 px-4">
          <Send size={16} />
        </button>
      </div>
    </div>
  )
}

function ElectionsTab() {
  return (
    <div className="card">
      <p className="font-semibold text-white mb-2">Guild Elections 2026</p>
      <p className="text-sm text-gray-500">No active elections at this time. Check back during the election period.</p>
    </div>
  )
}
