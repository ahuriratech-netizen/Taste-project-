import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { Zap, Mail, Lock, User, AlertCircle } from 'lucide-react'
import { authService } from '@/services/authService'
import { useAuthStore } from '@/store/authStore'

const ROLES = [
  { value: 'user',       label: 'General User' },
  { value: 'artist',     label: 'Music Artist' },
  { value: 'filmmaker',  label: 'Filmmaker' },
  { value: 'student',    label: 'Student' },
]

export default function RegisterPage() {
  const navigate = useNavigate()
  const setUser = useAuthStore((s) => s.setUser)
  const [form, setForm] = useState({ email: '', full_name: '', password: '', role: 'user' })
  const [error, setError] = useState('')

  const { mutate, isPending } = useMutation({
    mutationFn: () => authService.register(form),
    onSuccess: async () => {
      const user = await authService.getMe()
      setUser(user)
      navigate('/dashboard')
    },
    onError: (err: any) => {
      setError(err?.response?.data?.detail || 'Registration failed. Please try again.')
    },
  })

  return (
    <div className="min-h-screen bg-dark-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-brand-500 rounded-xl flex items-center justify-center">
            <Zap size={20} className="text-white" />
          </div>
          <div>
            <h1 className="font-display font-bold text-white text-lg leading-none">AHURIRA TECH</h1>
            <p className="text-xs text-gray-500">Kampala, Uganda</p>
          </div>
        </div>

        <div className="card">
          <h2 className="font-display text-2xl font-bold text-white mb-1">Create account</h2>
          <p className="text-gray-400 text-sm mb-6">Join Uganda's AI-powered platform</p>

          {error && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 text-red-400 text-sm rounded-lg p-3 mb-4">
              <AlertCircle size={16} className="flex-shrink-0" />
              {error}
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1.5">Full name</label>
              <div className="relative">
                <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  type="text"
                  className="input pl-9"
                  placeholder="Your full name"
                  value={form.full_name}
                  onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1.5">Email</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  type="email"
                  className="input pl-9"
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1.5">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  type="password"
                  className="input pl-9"
                  placeholder="Min 8 characters"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1.5">I am a…</label>
              <div className="grid grid-cols-2 gap-2">
                {ROLES.map((r) => (
                  <button
                    key={r.value}
                    onClick={() => setForm({ ...form, role: r.value })}
                    className={`py-2.5 px-3 rounded-lg text-sm font-medium border transition-all duration-200 ${
                      form.role === r.value
                        ? 'bg-brand-500/10 border-brand-500/50 text-brand-400'
                        : 'bg-dark-700 border-dark-500 text-gray-400 hover:text-white'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              className="btn-primary w-full mt-2"
              onClick={() => mutate()}
              disabled={isPending || !form.email || !form.password || !form.full_name}
            >
              {isPending ? 'Creating account…' : 'Create account'}
            </button>
          </div>

          <p className="text-center text-sm text-gray-500 mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-brand-400 hover:text-brand-300 font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
