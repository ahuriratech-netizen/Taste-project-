import { Link } from 'react-router-dom'
import { Bot, Music, Film, GraduationCap, ArrowRight, Zap } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'

const ENGINES = [
  {
    to: '/ai',
    icon: Bot,
    name: 'AHURIRA AI',
    description: 'Conversational AI, autonomous agents, content verification, and developer API.',
    color: 'from-violet-500/20 to-purple-500/10',
    border: 'border-violet-500/30 hover:border-violet-500/60',
    iconColor: 'text-violet-400',
    badge: 'Powered by Claude',
  },
  {
    to: '/music',
    icon: Music,
    name: 'Music Engine',
    description: 'Upload tracks, generate music with AI, stream, and track royalties.',
    color: 'from-brand-500/20 to-orange-500/10',
    border: 'border-brand-500/30 hover:border-brand-500/60',
    iconColor: 'text-brand-400',
    badge: 'Sonauto AI',
  },
  {
    to: '/film',
    icon: Film,
    name: 'Film Engine',
    description: 'OTT streaming, AI video generation, creator portal, and brand ads.',
    color: 'from-rose-500/20 to-pink-500/10',
    border: 'border-rose-500/30 hover:border-rose-500/60',
    iconColor: 'text-rose-400',
    badge: 'Seedance AI',
  },
  {
    to: '/portal',
    icon: GraduationCap,
    name: 'Student Portal',
    description: 'Academic records, mobile money payments, MIRA chatbot, and elections.',
    color: 'from-emerald-500/20 to-teal-500/10',
    border: 'border-emerald-500/30 hover:border-emerald-500/60',
    iconColor: 'text-emerald-400',
    badge: 'MIRA AI',
  },
]

export default function DashboardPage() {
  const user = useAuthStore((s) => s.user)

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center gap-2 mb-3">
          <Zap size={14} className="text-brand-400" />
          <span className="text-brand-400 text-sm font-medium uppercase tracking-wider">Platform</span>
        </div>
        <h1 className="font-display text-3xl font-bold text-white">
          Welcome back, {user?.full_name?.split(' ')[0]}
        </h1>
        <p className="text-gray-400 mt-1">
          Uganda's AI-powered platform — four engines, one mission.
        </p>
      </div>

      {/* Engine Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {ENGINES.map((engine) => {
          const Icon = engine.icon
          return (
            <Link
              key={engine.to}
              to={engine.to}
              className={`relative overflow-hidden rounded-xl border p-6 bg-gradient-to-br ${engine.color} ${engine.border} transition-all duration-300 group hover:scale-[1.01]`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-2.5 rounded-lg bg-dark-800/60 ${engine.iconColor}`}>
                  <Icon size={22} />
                </div>
                <span className="badge bg-dark-800/60 text-gray-400 border border-dark-500/50">
                  {engine.badge}
                </span>
              </div>
              <h3 className="font-display text-lg font-bold text-white mb-1.5">{engine.name}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{engine.description}</p>
              <div className={`flex items-center gap-1 mt-4 text-sm font-medium ${engine.iconColor} opacity-0 group-hover:opacity-100 transition-opacity duration-200`}>
                Open engine <ArrowRight size={14} />
              </div>
            </Link>
          )
        })}
      </div>

      {/* Status bar */}
      <div className="mt-8 card flex items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-sm text-gray-400">All systems operational</span>
        </div>
        <div className="h-4 w-px bg-dark-500" />
        <span className="text-sm text-gray-500">
          Account type: <span className="text-white capitalize">{user?.role}</span>
        </span>
        <div className="h-4 w-px bg-dark-500" />
        <span className="text-sm text-gray-500">Kampala, Uganda 🇺🇬</span>
      </div>
    </div>
  )
}
