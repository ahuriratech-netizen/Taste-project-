import { useState, useRef, useEffect } from 'react'
import { useMutation } from '@tanstack/react-query'
import { Bot, Send, User, Loader2, Sparkles } from 'lucide-react'
import { aiService, type ChatMessage } from '@/services/aiService'

export default function ChatPage() {
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const bottomRef = useRef<HTMLDivElement>(null)

  const { mutate, isPending } = useMutation({
    mutationFn: (message: string) =>
      aiService.chat({
        message,
        conversation_history: messages,
      }),
    onSuccess: (data) => {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: data.response },
      ])
    },
  })

  const send = () => {
    if (!input.trim() || isPending) return
    const userMsg = input.trim()
    setInput('')
    setMessages((prev) => [...prev, { role: 'user', content: userMsg }])
    mutate(userMsg)
  }

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isPending])

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-6 border-b border-dark-600 flex items-center gap-3">
        <div className="p-2 bg-violet-500/10 rounded-lg border border-violet-500/20">
          <Bot size={20} className="text-violet-400" />
        </div>
        <div>
          <h1 className="font-display font-bold text-white">AHURIRA AI</h1>
          <p className="text-xs text-gray-500">Powered by Claude · Kampala, Uganda</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs text-gray-500">Online</span>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-violet-500/10 border border-violet-500/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Sparkles size={28} className="text-violet-400" />
            </div>
            <h3 className="font-display text-xl font-bold text-white mb-2">How can I help?</h3>
            <p className="text-gray-500 text-sm max-w-md mx-auto">
              Ask me anything — creative writing, research, music concepts, film scripts,
              or general knowledge.
            </p>
            <div className="flex flex-wrap gap-2 justify-center mt-6">
              {['Write lyrics for an Afrobeats song', 'Summarise East African history', 'Help with my script idea'].map((s) => (
                <button
                  key={s}
                  onClick={() => { setInput(s); }}
                  className="text-xs bg-dark-700 border border-dark-500 text-gray-400 hover:text-white hover:border-dark-400 px-3 py-1.5 rounded-full transition-colors"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold ${
              msg.role === 'user'
                ? 'bg-brand-500/20 border border-brand-500/30 text-brand-400'
                : 'bg-violet-500/20 border border-violet-500/30 text-violet-400'
            }`}>
              {msg.role === 'user' ? <User size={14} /> : <Bot size={14} />}
            </div>
            <div className={`max-w-2xl px-4 py-3 rounded-xl text-sm leading-relaxed ${
              msg.role === 'user'
                ? 'bg-brand-500/10 border border-brand-500/20 text-white'
                : 'bg-dark-700 border border-dark-600 text-gray-200'
            }`}>
              <pre className="whitespace-pre-wrap font-sans">{msg.content}</pre>
            </div>
          </div>
        ))}

        {isPending && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-violet-500/20 border border-violet-500/30 text-violet-400 flex items-center justify-center">
              <Bot size={14} />
            </div>
            <div className="bg-dark-700 border border-dark-600 px-4 py-3 rounded-xl">
              <Loader2 size={16} className="text-violet-400 animate-spin" />
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="p-6 border-t border-dark-600">
        <div className="flex gap-3">
          <input
            type="text"
            className="input flex-1"
            placeholder="Message AHURIRA AI…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && send()}
          />
          <button
            onClick={send}
            disabled={isPending || !input.trim()}
            className="btn-primary px-4"
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </div>
  )
}
