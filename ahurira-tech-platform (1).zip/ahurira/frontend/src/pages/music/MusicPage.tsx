import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { Music, Sparkles, Upload, BarChart3, Loader2 } from 'lucide-react'
import { aiService } from '@/services/aiService'

export default function MusicPage() {
  const [prompt, setPrompt] = useState('')
  const [genre, setGenre] = useState('')
  const [result, setResult] = useState('')

  const { mutate, isPending } = useMutation({
    mutationFn: () => aiService.generateMusicConcept(prompt, genre),
    onSuccess: (data) => setResult(data.concept),
  })

  return (
    <div className="p-8">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3">
          <Music size={14} className="text-brand-400" />
          <span className="text-brand-400 text-sm font-medium uppercase tracking-wider">Music Engine</span>
        </div>
        <h1 className="font-display text-3xl font-bold text-white">AHURIRA Music</h1>
        <p className="text-gray-400 mt-1">Create, distribute, and monetise music with AI.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {[
          { icon: Upload, label: 'Upload Track', desc: 'Self-service artist portal' },
          { icon: Sparkles, label: 'AI Generate', desc: 'Sonauto music generation' },
          { icon: BarChart3, label: 'Royalties', desc: 'Automated payout tracking' },
        ].map(({ icon: Icon, label, desc }) => (
          <div key={label} className="card hover:border-brand-500/40 transition-colors cursor-pointer">
            <div className="p-2 bg-brand-500/10 rounded-lg w-fit mb-3">
              <Icon size={18} className="text-brand-400" />
            </div>
            <p className="font-semibold text-white">{label}</p>
            <p className="text-sm text-gray-500 mt-0.5">{desc}</p>
          </div>
        ))}
      </div>

      {/* AI Song Concept Generator */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles size={16} className="text-brand-400" />
          <h2 className="font-display font-bold text-white">AI Song Concept Generator</h2>
        </div>
        <p className="text-sm text-gray-400 mb-4">Describe your idea and AI will generate complete lyrics, structure and production notes.</p>

        <div className="space-y-3 mb-4">
          <input
            className="input"
            placeholder="Describe your song concept… e.g. 'A love song about Kampala nights'"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
          <input
            className="input"
            placeholder="Genre (optional) — e.g. Afrobeats, Bongo Flava, R&B"
            value={genre}
            onChange={(e) => setGenre(e.target.value)}
          />
          <button
            className="btn-primary"
            onClick={() => mutate()}
            disabled={isPending || !prompt.trim()}
          >
            {isPending ? (
              <span className="flex items-center gap-2"><Loader2 size={16} className="animate-spin" /> Generating…</span>
            ) : (
              'Generate concept'
            )}
          </button>
        </div>

        {result && (
          <div className="mt-4 p-4 bg-dark-700 rounded-lg border border-dark-500">
            <pre className="text-sm text-gray-200 whitespace-pre-wrap font-sans leading-relaxed">{result}</pre>
          </div>
        )}
      </div>
    </div>
  )
}
