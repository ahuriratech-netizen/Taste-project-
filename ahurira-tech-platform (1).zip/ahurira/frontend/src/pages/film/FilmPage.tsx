import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { Film, Sparkles, Upload, Briefcase, Loader2 } from 'lucide-react'
import { aiService } from '@/services/aiService'

export default function FilmPage() {
  const [prompt, setPrompt] = useState('')
  const [style, setStyle] = useState('')
  const [result, setResult] = useState('')

  const { mutate, isPending } = useMutation({
    mutationFn: () => aiService.generateFilmScript(prompt, style),
    onSuccess: (data) => setResult(data.script),
  })

  return (
    <div className="p-8">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3">
          <Film size={14} className="text-rose-400" />
          <span className="text-rose-400 text-sm font-medium uppercase tracking-wider">Film Engine</span>
        </div>
        <h1 className="font-display text-3xl font-bold text-white">AHURIRA Film</h1>
        <p className="text-gray-400 mt-1">OTT streaming, AI video generation, and creator monetisation.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {[
          { icon: Upload, label: 'Creator Portal', desc: 'Upload & monetise your films' },
          { icon: Sparkles, label: 'AI Generate', desc: 'Seedance AI video generation' },
          { icon: Briefcase, label: 'B2B Ads', desc: 'Enterprise brand video requests' },
        ].map(({ icon: Icon, label, desc }) => (
          <div key={label} className="card hover:border-rose-500/40 transition-colors cursor-pointer">
            <div className="p-2 bg-rose-500/10 rounded-lg w-fit mb-3">
              <Icon size={18} className="text-rose-400" />
            </div>
            <p className="font-semibold text-white">{label}</p>
            <p className="text-sm text-gray-500 mt-0.5">{desc}</p>
          </div>
        ))}
      </div>

      {/* AI Script Generator */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles size={16} className="text-rose-400" />
          <h2 className="font-display font-bold text-white">AI Script Generator</h2>
        </div>
        <p className="text-sm text-gray-400 mb-4">
          Describe your film idea and AI will draft a logline, characters, structure, and opening scene.
        </p>

        <div className="space-y-3 mb-4">
          <input
            className="input"
            placeholder="Describe your film idea… e.g. 'A boda boda rider's journey to Kampala'"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
          <input
            className="input"
            placeholder="Style (optional) — e.g. Drama, Comedy, Documentary"
            value={style}
            onChange={(e) => setStyle(e.target.value)}
          />
          <button
            className="btn-primary bg-rose-500 hover:bg-rose-600"
            onClick={() => mutate()}
            disabled={isPending || !prompt.trim()}
          >
            {isPending ? (
              <span className="flex items-center gap-2"><Loader2 size={16} className="animate-spin" /> Generating…</span>
            ) : (
              'Generate script'
            )}
          </button>
        </div>

        {result && (
          <div className="mt-4 p-4 bg-dark-700 rounded-lg border border-dark-500">
            <pre className="text-sm text-gray-200 whitespace-pre-wrap font-sans leading-relaxed">{result}</pre>
          </div>
        )}
      </div>
    </div>
  )
}
