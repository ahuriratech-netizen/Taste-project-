import { apiClient } from './apiClient'

export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

export interface ChatRequest {
  message: string
  conversation_history?: ChatMessage[]
  system_prompt?: string
}

export interface ChatResponse {
  response: string
  tokens_used: number
  conversation_id?: string
}

export const aiService = {
  async chat(request: ChatRequest): Promise<ChatResponse> {
    const res = await apiClient.post<ChatResponse>('/ai/chat', request)
    return res.data
  },

  async miraChat(request: ChatRequest): Promise<ChatResponse> {
    const res = await apiClient.post<ChatResponse>('/ai/mira/chat', request)
    return res.data
  },

  async generateMusicConcept(prompt: string, genre?: string, mood?: string) {
    const res = await apiClient.post('/ai/music/concept', {
      prompt,
      genre,
      mood,
      duration_seconds: 30,
    })
    return res.data
  },

  async generateFilmScript(script: string, style?: string) {
    const res = await apiClient.post('/ai/film/script', {
      script,
      style,
      duration_seconds: 60,
    })
    return res.data
  },

  async verifyContent(content: string, content_type = 'text') {
    const res = await apiClient.post('/ai/verify', null, {
      params: { content, content_type },
    })
    return res.data
  },
}
