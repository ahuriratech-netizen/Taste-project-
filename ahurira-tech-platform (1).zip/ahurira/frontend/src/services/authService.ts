import { apiClient } from './apiClient'

export interface RegisterData {
  email: string
  full_name: string
  password: string
  role?: string
}

export interface LoginData {
  email: string
  password: string
}

export interface TokenResponse {
  access_token: string
  refresh_token: string
  token_type: string
}

export interface User {
  id: string
  email: string
  full_name: string
  role: string
  is_active: boolean
  is_verified: boolean
  avatar_url?: string
}

export const authService = {
  async register(data: RegisterData): Promise<TokenResponse> {
    const res = await apiClient.post<TokenResponse>('/auth/register', data)
    return res.data
  },

  async login(data: LoginData): Promise<TokenResponse> {
    const res = await apiClient.post<TokenResponse>('/auth/login', data)
    localStorage.setItem('access_token', res.data.access_token)
    localStorage.setItem('refresh_token', res.data.refresh_token)
    return res.data
  },

  async getMe(): Promise<User> {
    const res = await apiClient.get<User>('/auth/me')
    return res.data
  },

  logout() {
    localStorage.removeItem('access_token')
    localStorage.removeItem('refresh_token')
  },

  isAuthenticated(): boolean {
    return !!localStorage.getItem('access_token')
  },
}
